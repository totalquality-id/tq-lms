## Konfigurasi database dan akun

Aplikasi memakai project Supabase **tq-lms** (`hdjumgxtubpruwlluahs`), skema `lms`, dengan peran Postgres `tq_lms_app`. Database, Supabase Auth, dan Storage harus berasal dari project yang sama. Project lama `totalquality-website` bukan sumber data aplikasi ini lagi.

`DATABASE_URL` menggunakan transaction pooler port 6543 dengan `pgbouncer=true&connection_limit=5&schema=lms&sslmode=require`. `DIRECT_URL` menggunakan session pooler port 5432 dengan `schema=lms&sslmode=require` untuk migrasi. Host pooler tersedia di panel Connect Supabase; username memakai format `tq_lms_app.<project-ref>`.

Nilai rahasia tersimpan pada `.env` lokal dan Environment Variables Vercel. `.env.supabase-secret` menyimpan salinan koneksi deployment. Berkas tersebut serta folder `.local/` diabaikan Git dan tidak diunggah ke Vercel.

## Menjalankan lokal

Gunakan Node.js 22+. Salin `.env.example` menjadi `.env` hanya pada instalasi baru, lalu isi koneksi project dan kunci Supabase. Set `AUTH_URL=http://localhost:3000`, buat `AUTH_SECRET` acak, dan gunakan `ENABLE_DEMO_AUTH=false`.

```powershell
npm ci
npm run db:deploy
npm run db:seed
npm run dev
```

`db:deploy` menerapkan migrasi yang sudah tersedia. `db:migrate` khusus membuat migrasi baru pada database pengembangan terpisah; isi `SHADOW_DATABASE_URL` dengan database sementara yang terpisah. Jangan memakai database aplikasi sebagai shadow database.

Seed hanya membuat atau memperbarui:

- Organisasi PT Globalindo Intimates.
- Admin `center@tq-official.com` (SUPER_ADMIN).
- Sembilan trainer yang tercantum dalam `prisma/seed.ts`.
- Sepuluh peserta: `participant@globalindointimates.com` dan `participant2@globalindointimates.com` sampai `participant10@globalindointimates.com`, seluruhnya anggota PT Globalindo Intimates.

Seed tidak membuat course, training, soal, aktivitas belajar, nilai, atau sertifikat. Menjalankannya ulang tidak menggandakan akun dan tidak menghapus pekerjaan yang sudah dibuat. Ini bukan perintah reset database. Seluruh akun menggunakan Supabase Auth sungguhan (`isDemo=false`); seed tidak menetapkan password bersama atau mengirim email.

Untuk akun baru, administrator dapat membuat tautan pengaturan password dari halaman Pengguna. Tautan bootstrap awal disimpan secara lokal pada `.env.deployment-access.md`; tautan berlaku sekali selama tujuh hari sejak dibuat. Jangan membagikan berkas seluruh akun kepada peserta.

## Deployment

Live: **https://tq-lms.vercel.app** (project Vercel `tq-lms`, region `sin1`).

Production dan preview memakai koneksi Supabase `tq-lms` yang sama. `ENABLE_DEMO_AUTH=false`. Perubahan Environment Variables berlaku setelah deployment baru dibuat.

Bucket `training-resources` bersifat privat. Jalankan `npm run storage:setup` untuk memeriksa unggah, metadata, unduh bertanda tangan, dan penghapusan file uji.

