import http from 'node:http';
import { PrismaClient } from '@prisma/client';
import { encode } from 'next-auth/jwt';
import { chromium, expect } from '@playwright/test';
import assert from 'node:assert/strict';

const db = new PrismaClient();
let browser;
// Retain the first real Next.js streaming chunk; delay later chunks to
// exercise its actual Suspense fallback without modifying app or database.
const proxy = http.createServer((req, res) => {
  const upstream = http.request({ hostname: '127.0.0.1', port: 3100, path: req.url, method: req.method, headers: { ...req.headers, host: '127.0.0.1:3100', 'accept-encoding': 'identity' } }, response => {
    res.writeHead(response.statusCode, response.headers);
    const slow = response.headers['content-type']?.includes('text/html') || req.headers.rsc;
    let first = true, released = !slow, ended = false; let prefix = ''; 
    const queue = [];
    response.on('data', chunk => {
      if (first && slow) {
        res.write(chunk);
        prefix += chunk.toString();
        if (!prefix.includes('Memuat halaman, mohon tunggu.')) return;
        first = false;
        setTimeout(() => { released = true; for (const part of queue) res.write(part); if (ended) res.end(); }, 2500);
      } else if (released) res.write(chunk);
      else queue.push(chunk);
    });
    response.on('end', () => { ended = true; if (released || first) res.end(); });
  });
  upstream.on('error', () => { if (!res.headersSent) res.writeHead(502); res.end(); });
  req.pipe(upstream);
});
await new Promise(resolve => proxy.listen(3101, '127.0.0.1', resolve));
try {
  const admin = await db.user.findUniqueOrThrow({ where: { email: 'center@tq-official.com' } });
  const token = await encode({ token: { sub: admin.id }, secret: process.env.AUTH_SECRET, salt: 'authjs.session-token', maxAge: 600 });
  browser = await chromium.launch({ channel: 'msedge', headless: true });
  const context = await browser.newContext({ viewport: { width: 1365, height: 900 } });
  await context.addCookies([{ name: 'authjs.session-token', value: token, url: 'http://127.0.0.1:3101', httpOnly: true }]);
  const page = await context.newPage();
  await page.route('**/*', async route => {
    if (route.request().headers().rsc) await new Promise(resolve => setTimeout(resolve, 3000));
    await route.continue();
  });
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  await page.goto('http://127.0.0.1:3101/admin/question-bank', { waitUntil: 'commit' });
  const indicator = page.getByRole('status').filter({ hasText: 'Memuat halaman, mohon tunggu.' });
  await expect(indicator).toBeVisible();
  await expect(indicator).toHaveCSS('opacity', '1');
  const bounds = await indicator.boundingBox();
  assert.ok(bounds.y >= 0 && bounds.y < 30 && bounds.width === 48);
  await expect(indicator).toHaveCSS('pointer-events', 'none');
  await page.screenshot({ path: '.local/loading-desktop.png' });
  await expect(page.getByRole('heading', { name: 'Bank soal', exact: true })).toBeVisible();
  await expect(indicator).toHaveCount(0);
  // Client navigation uses the workspace loading boundary.
  await page.getByRole('link', { name: /^Kelola soal / }).first().click();
  await expect(indicator).toBeVisible();
  await expect(indicator).toHaveCSS('opacity', '1');
  await page.screenshot({path: '.local/loading-navigation.png'});
  await expect(page.getByRole('heading', { name: 'Kelola soal', exact: true })).toBeVisible();
  await expect(indicator).toHaveCount(0);
  await page.setViewportSize({ width: 390, height: 844 });
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.goto('http://127.0.0.1:3101/admin/question-bank', { waitUntil: 'commit' });
  await expect(indicator).toBeVisible();
  await expect(indicator).toHaveCSS('animation-name', 'none');
  await expect(indicator.locator('.page-loading-ring')).toHaveCSS('animation-name', 'none');
  await page.screenshot({ path: '.local/loading-mobile.png' });
  await expect(page.getByRole('heading', { name: 'Bank soal', exact: true })).toBeVisible();
  await expect(indicator).toHaveCount(0);
  assert.deepEqual(errors, []);
  console.log('PASS: actual streamed initial load and client navigation; indicator disappears on completion, top-center placement, no blocked clicks, mobile and reduced-motion.');
} finally {
  await browser?.close();
  proxy.closeAllConnections();
  await new Promise(resolve => proxy.close(resolve));
  await db.$disconnect();
}
