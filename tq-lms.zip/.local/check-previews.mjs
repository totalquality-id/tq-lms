import assert from 'node:assert/strict';
import { PrismaClient } from '@prisma/client';
import { encode } from 'next-auth/jwt';
import { chromium, expect } from '@playwright/test';
const db = new PrismaClient();
const base = 'http://127.0.0.1:3000';
let browser;
try {
  const admin = await db.user.findFirstOrThrow({where:{role:{in:['ADMIN','SUPER_ADMIN']},active:true,deletedAt:null}});
  const batch = await db.trainingBatch.findFirstOrThrow({where:{deletedAt:null,assessments:{some:{deletedAt:null}}},include:{assessments:{where:{deletedAt:null},include:{questions:true}},course:{include:{modules:{include:{lessons:true}}}}}});
  const counts = async () => Promise.all([db.assessmentAttempt.count(),db.assessmentAnswer.count(),db.assignmentSubmission.count(),db.evaluationResponse.count(),db.lessonCompletion.count()]);
  const before = await counts();
  const token = await encode({token:{sub:admin.id},secret:process.env.AUTH_SECRET,salt:'authjs.session-token',maxAge:600});
  browser = await chromium.launch({channel:'msedge',headless:true});
  const context = await browser.newContext({viewport:{width:1365,height:1000}});
  await context.addCookies([{name:'authjs.session-token',value:token,url:base,httpOnly:true,sameSite:'Lax'}]);
  const page = await context.newPage();
  page.setDefaultTimeout(30000);
  const errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.goto(`${base}/admin/training/${batch.id}/assessments`);
  await page.getByRole('button',{name:'Preview',exact:true}).first().click();
  let dialog=page.getByRole('dialog');
  await expect(dialog).toBeVisible();
  await expect(dialog.getByText('Memuat soal…')).not.toBeVisible();
  assert.equal(await page.locator('html').evaluate(el=>getComputedStyle(el).getPropertyValue('--color-brand-600').trim()),'#173e76');
  if (await dialog.getByRole('button',{name:'Kirim jawaban',exact:true}).count()) {
    await expect(dialog.getByRole('button',{name:'Kirim jawaban',exact:true})).toBeDisabled();
    if(await dialog.getByRole('radio').count()) await dialog.getByRole('radio').first().check();
    if(await dialog.getByRole('checkbox').count()) await dialog.getByRole('checkbox').first().check();
    await dialog.locator('form').evaluate(form=>form.requestSubmit());
    console.log('PASS assessment preview: questions loaded, interactive, submission disabled');
  } else {
    await expect(dialog.getByText(/soal.*kosong/)).toBeVisible();
    console.log('PASS assessment preview: empty selection reported');
  }
  await page.screenshot({path:'.local/assessment-preview-desktop.png'});
  await page.setViewportSize({width:390,height:844});
  await expect(dialog).toBeVisible();
  assert.ok(await dialog.evaluate(el=>el.scrollWidth<=el.clientWidth));
  await page.screenshot({path:'.local/assessment-preview-mobile.png'});
  await dialog.getByRole('button',{name:'Tutup',exact:true}).click();
  await page.goto(`${base}/admin/training/${batch.id}/evaluation`);
  await page.getByRole('button',{name:'Preview',exact:true}).click();
  dialog=page.getByRole('dialog');
  await expect(dialog.getByRole('button',{name:'Kirim evaluasi'})).toBeDisabled();
  for(const group of await dialog.getByRole('radiogroup').all()) await group.getByRole('radio').last().check();
  await dialog.locator('form').evaluate(form=>form.requestSubmit());
  await page.screenshot({path:'.local/evaluation-preview-mobile.png'});
  console.log('PASS evaluation preview before opening evaluation: interactive, submission disabled');
  await dialog.getByRole('button',{name:'Tutup',exact:true}).click();
  await page.goto(`${base}/admin/training/${batch.id}`);
  if(batch.course.modules.some(m=>m.lessons.length)) {
    await page.getByRole('button',{name:'Preview',exact:true}).first().click();
    await expect(page.getByRole('dialog')).toBeVisible();
    await page.screenshot({path:'.local/lesson-preview-mobile.png'});
    console.log('PASS lesson preview');
  }
  assert.deepEqual(await counts(),before,'Preview must not write participant data');
  assert.deepEqual(errors,[]);
  console.log('PASS preview did not change attempts, answers, submissions, evaluations or completions');
} finally { await browser?.close();await db.$disconnect(); }
