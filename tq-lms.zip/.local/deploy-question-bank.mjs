import fs from 'node:fs';
const project = JSON.parse(fs.readFileSync('.vercel/project.json', 'utf8'));
const paths = JSON.parse(fs.readFileSync('.local/deploy-files.json', 'utf8'));
const files = paths.map(file => ({ file, data: fs.readFileSync(file).toString('base64'), encoding: 'base64' }));
const response = await fetch(`https://api.vercel.com/v13/deployments?teamId=${project.orgId}`, {
  method: 'POST',
  headers: { Authorization: `Bearer ${process.env.VERCEL_TOKEN}`, 'Content-Type': 'application/json' },
  body: JSON.stringify({ name: project.projectName, project: project.projectId, target: 'production', files, projectSettings: { framework: 'nextjs', buildCommand: 'npm run build' } }),
});
const result = await response.json();
if (!response.ok) throw new Error(JSON.stringify(result.error));
fs.writeFileSync('.local/question-bank-deployment.json', JSON.stringify({ id: result.id, url: result.url }));
console.log(JSON.stringify({ id: result.id, url: result.url, readyState: result.readyState }));
