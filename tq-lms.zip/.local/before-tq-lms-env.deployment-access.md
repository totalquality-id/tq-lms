# Akses deployment TQ Learning

URL: https://tq-lms.vercel.app

Berkas ini berisi kata sandi. Sudah diabaikan git (.env*).
Jangan dibagikan di luar tim, dan ganti kata sandinya sebelum dipakai nyata.

## Akun aplikasi (Supabase Auth)

- Administrator
  email    : admin@totalquality.local
  kata sandi: UVqxWLWJQ7Tveu7x

- Trainer
  email    : trainer@totalquality.local
  kata sandi: 5QvIbU8lYjdWP7x

- Peserta
  email    : participant@globalindo.local
  kata sandi: 9On91mJ78TczSt7x

- PIC Perusahaan
  email    : pic@globalindo.local
  kata sandi: SFqwvtiYkT7ods7x

## Database

Supabase project : picdgwdwrzumeinjwizw (totalquality-website)
Skema            : lms  (terpisah penuh dari skema public milik website)
Peran Postgres   : tq_lms_app
Kata sandi peran : hjWH8LYBBQQ1bDYll7QFAVZAAvNK

Peran ini hanya diberi hak pada skema lms. Kata sandi database milik
website tidak diubah sama sekali.
