import Link from "@/components/ui/navigation-link";

import { Brand } from "@/components/layout/brand";
import { MobileNav } from "@/components/layout/app-nav";
import { NotificationBell } from "@/components/layout/notification-bell";
import { UserMenu } from "@/components/layout/user-menu";
import type { NavGroup, Workspace } from "@/lib/navigation";
import type { NotificationPanel } from "@/services/notification";

export function AppHeader({
  user,
  groups,
  workspace,
  home,
  notifications,
}: {
  user: { name: string; email: string; roleLabel: string };
  groups: NavGroup[];
  workspace: Workspace;
  home: string;
  notifications: NotificationPanel;
}) {
  return (
    <header className="no-print sticky top-0 z-40 border-b border-ink-200 bg-white">
      <div className="flex h-14 items-center gap-2 px-3 sm:px-4">
        {/* Berada sebelum tanda perusahaan agar menu menjadi hal pertama yang
            dijangkau ibu jari pada ponsel, sesuai kebiasaan platform. */}
        <MobileNav groups={groups} workspace={workspace} />
        <Link href={home} className="min-w-0 rounded-md">
          <Brand />
        </Link>
        <div className="ml-auto flex items-center gap-1">
          <NotificationBell {...notifications} />
          <UserMenu
            name={user.name}
            email={user.email}
            roleLabel={user.roleLabel}
          />
        </div>
      </div>
    </header>
  );
}
